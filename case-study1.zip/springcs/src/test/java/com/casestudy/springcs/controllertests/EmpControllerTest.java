package com.casestudy.springcs.controllertests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.casestudy.springcs.controller.EmpController;
import com.casestudy.springcs.dao.EmpDao;
import com.casestudy.springcs.dto.EmpDto;



public class EmpControllerTest {
	
	
	@Mock
	EmpDao empdao;
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	@InjectMocks
	EmpController empcon;
	
	@Test
	public void getAllEmployee()
	{
	   
		List<EmpDto> list=new ArrayList<EmpDto>();
        EmpDto e1=new EmpDto(1733117,"Venkatachalam","Trainee","Siruseri","9629617734");
        EmpDto e2=new EmpDto(1733606,"NehruKumar","Trainee","Siruseri","8675091571");
        EmpDto e3=new EmpDto(1623930,"DeepakGupta","Trainee","Siruseri","9506001402");
        EmpDto e4=new EmpDto(1438182,"Ramshad","Trainee","Siruseri","8675091571");
        
        list.add(e1);
        list.add(e2);
        list.add(e3);
        list.add(e4);
        
        for(EmpDto e:list)
         {
        	System.out.println(e.getEmp_id()+" "+e.getEmp_name()+" "+e.getDesignation()+" "+e.getAddress()+" "+e.getPhone());
         }

        when(empdao.getAllEmployee()).thenReturn(list);
        List<EmpDto> lest=empcon.getAll();
        assertEquals(list,lest);
        }
	
	
	@Test
	public void getEmployee()
	{
		final int testid=1733117;
		EmpDto e1=new EmpDto(1733117,"Venkatachalam","Trainee","Siruseri","9629617734");
		when(empdao.getEmployee(testid)).thenReturn(e1);
		EmpDto actual=empcon.getId(testid);
		assertEquals(e1, actual);
		
	}
	
	
@Test
	public void addDetails(){
		final String str="Details Successfully Added";
		when(empdao.addDetails(1733117,"Venkatachalam","Trainee","Siruseri","9629617734")).thenReturn(1);
		String actual= empcon.addDetails(1733117,"Venkatachalam","Trainee","Siruseri","9629617734");
		assertEquals(str,actual);
	}
	
	@Test
	public void deleteDetails(){
		final int testid=1733117;
		String str="Deleted Successfully";
		when(empdao.deleteDetails(testid)).thenReturn(1);
		String actual = empcon.deleteDetails(testid);
		assertEquals(str,actual);
	}
	@Test
	public void updateDetails()
	{
		String str="Successfully Updated";
		when(empdao.updateDetails(1733117,"Nehrukumar")).thenReturn(1);
		String actual=empcon.updateDetails(1733117,"Nehrukumar");
		assertEquals(str,actual);
	}
	
}