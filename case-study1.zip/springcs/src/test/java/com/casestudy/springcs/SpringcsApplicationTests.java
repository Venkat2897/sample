package com.casestudy.springcs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcsApplicationTests {

	@Test
	void contextLoads() {
	}

}
