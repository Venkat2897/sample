package com.casestudy.springcs.controllertests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.casestudy.springcs.controller.DeptController;
import com.casestudy.springcs.dao.DeptDao;
import com.casestudy.springcs.dto.DeptDto;

public class DeptControllerTest {
	

	@Mock
	DeptDao deptdao;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	@InjectMocks
	DeptController deptcon;
	
	@Test
	public void getAllEmployee()
	{
	   
		List<DeptDto> list=new ArrayList<DeptDto>();
        DeptDto e1=new DeptDto(10001,"THD STORES","Siruseri",1733117);
        DeptDto e2=new DeptDto(10001,"THD STORES","Siruseri",1733117);
        DeptDto e3=new DeptDto(10001,"THD STORES","Siruseri",1733117);
        DeptDto e4=new DeptDto(10001,"THD STORES","Siruseri",1733117);
        
        list.add(e1);
        list.add(e2);
        list.add(e3);
        list.add(e4);
        
        for(DeptDto e:list)
         {
        	System.out.println(e.getDept_id()+" "+e.getDept_name()+" "+e.getDept_loc()+" "+e.getEmp_id());
         }

        when(deptdao.getAllDepartment()).thenReturn(list);
        List<DeptDto> lest=deptcon.getAll();
        assertEquals(list,lest);
        }
	
	
	@Test
	public void getEmployee()
	{
		final int testid=10001;
		DeptDto e1=new DeptDto(10001,"THD STORES","Siruseri",1733117);
		when(deptdao.getDepartment(testid)).thenReturn(e1);
		DeptDto actual=deptcon.getId(testid);
		assertEquals(e1, actual);
		
	}
	
	
@Test
	public void addDetails(){
		final String str="Details Successfully Added";
		when(deptdao.addDeptDetails(10001,"THD STORES","Siruseri",1733117)).thenReturn(1);
		String actual= deptcon.addDeptDetails(10001,"THD STORES","Siruseri",1733117);
		assertEquals(str,actual);
	}
	
	@Test
	public void deleteDetails(){
		final int testid=10001;
		String str="Deleted Successfully";
		when(deptdao.deleteDeptDetails(testid)).thenReturn(1);
		String actual = deptcon.deleteDeptDetails(testid);
		assertEquals(str,actual);
	}
	@Test
	public void updateDetails()
	{
		String str="Successfully Updated";
		when(deptdao.updateDeptDetails(10001,"THD STORES")).thenReturn(1);
		String actual=	deptcon.updateDeptDetails(10001,"THD STORES");
		assertEquals(str,actual);
	}
	
}


