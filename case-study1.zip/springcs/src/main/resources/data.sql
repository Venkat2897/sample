insert into employee
values(1733117,'Venkatachalam','Trainee','Siruseri',9629617734);
insert into employee
values(1733606,'NehruKumar','Trainee','Siruseri',8675091571);
insert into employee
values(1623930,'DeepakGupta','Trainee','Siruseri',9506001402);
insert into employee
values(1438182,'Ramshad','Trainee','Siruseri',8675091571);

insert into department
values(10001,'THD STORES','Siruseri',1733117);
insert into department
values(10002,'THD STORES','Siruseri',1733606);
insert into department
values(10003,'THD STORES','Siruseri',1623930);
insert into department
values(10004,'THD STORES','Siruseri',1438182);