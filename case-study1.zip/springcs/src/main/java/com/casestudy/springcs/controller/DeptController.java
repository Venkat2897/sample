package com.casestudy.springcs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.springcs.dao.DeptDao;
import com.casestudy.springcs.dto.DeptDto;
import com.casestudy.springcs.exceptions.RecordNotFoundException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;



@Api(value="Department Management System",description ="Operations pertaining to department in Department Management System")
@RestController
public class DeptController {
	
	@Autowired
	DeptDao deptdao;
	
      @ApiOperation(value="views list if available departments", response=List.class)
      @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Department Details Retrived Successfully"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "Department details not found!!!") })
	  @GetMapping("/getAllDept")
      @ResponseBody
      public List<DeptDto> getAll(){
              return deptdao.getAllDepartment();
      }
     
      @ApiOperation(value="get department details by id")
      @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Department Detail Shown Successfully"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "Department Id not Found") })
      @GetMapping("/getDepartment")
      @ResponseBody
      public DeptDto getId(@RequestParam int id) {
    	  if(id<=0)
    	  {
    		  throw new RecordNotFoundException("invalid id");
    	  }
             
              return deptdao.getDepartment(id);
      }
     
      @ApiOperation(value="add department details")
      @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Details Added Successfully"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "not found!!!") })
      @PostMapping("/AddDeptDetails")
      public String addDeptDetails(@RequestParam("dept_id")int id,@RequestParam("dept_name")String dept_name,@RequestParam("dept_loc")String location,@RequestParam("emp_id")int empid) {
              if(deptdao.addDeptDetails(id,dept_name,location,empid)>=1) {
                      return "Details Successfully Added";
              }else {
            	  throw new RecordNotFoundException("invalid id");}
      }
     
      @ApiOperation(value="delete department details")
      @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Deapartment Deletion Success"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "not found!!!") })
      @DeleteMapping("/DeleteDeptDetails")
      public String deleteDeptDetails(@RequestParam("dept_id")int id) {
              if(deptdao.deleteDeptDetails(id)>=1) {
                      return "Deleted Successfully";
              }else {
            	  throw new RecordNotFoundException("invalid id");}
      }
     
      @ApiOperation(value="update department details")
      @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Deatils Updation Success"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "not found!!!") })
      @PutMapping("/UpdateDeptDetails")
      public String updateDeptDetails(@RequestParam("dept_id")int id,@RequestParam("dept_name")String name) {
              if(deptdao.updateDeptDetails(id,name)>=1) {
                      return "Successfully Updated";
              }else {
            	  throw new RecordNotFoundException("invalid id");
              }
      }
     
     


}
