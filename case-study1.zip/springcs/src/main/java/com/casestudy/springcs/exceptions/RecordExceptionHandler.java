package com.casestudy.springcs.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class RecordExceptionHandler {
	
	
	 @ExceptionHandler
	    public ResponseEntity<RecordErrorResponse> handleException(RecordNotFoundException ine){
	        RecordErrorResponse errorResponse = new RecordErrorResponse();
	        errorResponse.setStatus(HttpStatus.NOT_FOUND.value());
	        errorResponse.setMessage(ine.getMessage());
	        errorResponse.setTimestamp(System.currentTimeMillis());
	        return new ResponseEntity<RecordErrorResponse>(errorResponse,HttpStatus.NOT_FOUND);
	    }

	    @ExceptionHandler
	    public ResponseEntity<RecordErrorResponse> handleException(Exception ex){
	        RecordErrorResponse errorResponse = new RecordErrorResponse();
	        errorResponse.setStatus(HttpStatus.BAD_REQUEST.value());
	        errorResponse.setMessage(ex.getMessage());
	        errorResponse.setTimestamp(System.currentTimeMillis());
	        return new ResponseEntity<RecordErrorResponse>(errorResponse,HttpStatus.BAD_REQUEST);
	    }

}
