package com.casestudy.springcs.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


import io.swagger.annotations.ApiModelProperty;

public class EmpDto {
	
	
	@ApiModelProperty(notes = "The database generated Employee ID")
	@NotNull(message="Please Provide ID")
	@Min(value=3,message="ID should not be smaller than three digit")
	@Max(value=8,message="ID should not be greater than eight digit")
	private int emp_id;
	
    @ApiModelProperty(notes = "The Employee name")
    @NotEmpty(message="name should not be empty")
	private String emp_name;
	 
	@ApiModelProperty(notes = "The Employee Designation")
	@NotEmpty(message="Designation should not be Empty")
	private String designation;
	 
	@ApiModelProperty(notes = "The Employee's Address")
	@NotEmpty(message="Address should not be empty")
	private String address;
	 
	@ApiModelProperty(notes = "The Employee's Contact Number")
	@NotNull(message="Phone Number should not be null")
	private String phone;
	
	
	public EmpDto() {
		super();
		
	}


	public EmpDto(int emp_id, String emp_name, String designation, String address, String phone) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.designation = designation;
		this.address = address;
		this.phone = phone;
	}


	public int getEmp_id() {
		return emp_id;
	}


	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}


	public String getEmp_name() {
		return emp_name;
	}


	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}

    



}
