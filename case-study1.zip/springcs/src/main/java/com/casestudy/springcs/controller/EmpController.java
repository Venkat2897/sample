package com.casestudy.springcs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.springcs.dao.EmpDao;
import com.casestudy.springcs.dto.EmpDto;
import com.casestudy.springcs.exceptions.RecordNotFoundException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;



@Api(value="Employee Management System",description ="Operations pertaining to employee in Employee Management System")
@RestController
@Validated
public class EmpController {
	
	
	
	@Autowired
	EmpDao empdao;
	
	  @ApiOperation(value = "View a list of available employees", response = List.class)
	  @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Success|OK"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "not found!!!") })
	  @GetMapping("/getAll")
      @ResponseBody
      public List<EmpDto> getAll(){
              return empdao.getAllEmployee();
		  	  
		  }
     
	  @ApiOperation(value ="get a employee details by id")
	  @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Success|OK"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "not found!!!") })
	  @ApiResponse(code=500,message="ID Not Found",response=List.class)
	  @GetMapping("/getEmployee")
      @ResponseBody
      public EmpDto getId(@RequestParam int id) 
	  {
		  if(id<=0)
		  {
			  throw new RecordNotFoundException("invalid id");
		  }
              return empdao.getEmployee(id);
	  }
              
     
	  @ApiOperation(value ="add the employee details")
	  @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Success|OK"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "not found!!!") })
      @PostMapping("/AddDetails")
      public String addDetails(@RequestParam("emp_id")int id,@RequestParam("emp_name")String emp_name,@RequestParam("designation")String emp_desg,@RequestParam("address")String emp_addr,@RequestParam("phone")String emp_phn) {
              if(empdao.addDetails(id,emp_name,emp_desg,emp_addr,emp_phn)>=1) {
                      return "Details Successfully Added";
              }else {
            	  throw new RecordNotFoundException("invalid id");}
      }
     
	  @ApiOperation(value ="delete the employee details")
	  @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Success|OK"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "not found!!!"),
	            @ApiResponse(code=500,message="ID Not Found")})
      @DeleteMapping("/DeleteDetails")
      public String deleteDetails(@RequestParam("emp_id")int id)
	  {
              if(empdao.deleteDetails(id)>=1) {
                      return "Deleted Successfully";
              }else {
            	  throw new RecordNotFoundException("invalid id");}
      }
      
	  
	  @ApiOperation(value ="update the employee details")
	  @ApiResponses(value = { 
	            @ApiResponse(code = 200, message = "Success|OK"),
	            @ApiResponse(code = 401, message = "not authorized!"), 
	            @ApiResponse(code = 403, message = "forbidden!!!"),
	            @ApiResponse(code = 404, message = "not found!!!") })
      @PutMapping("/UpdateDetails")
      public String updateDetails(@RequestParam("emp_id")int id,@RequestParam("emp_name")String name) {
              if(empdao.updateDetails(id,name)>=1) {
                      return "Successfully Updated";
              }else {
            	  throw new RecordNotFoundException("invalid id");
              }
      }
     

}
