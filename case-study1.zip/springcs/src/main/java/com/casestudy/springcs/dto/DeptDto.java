package com.casestudy.springcs.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;

public class DeptDto {
	
	@ApiModelProperty(notes = "The database generated Department ID")
	@NotNull(message="Please Provide ID")
	@Min(value=3,message="ID should not be smaller than three digit")
	@Max(value=8,message="ID should not be greater than eight digit")
	private int dept_id;
	
	@ApiModelProperty(notes = "The Department name")
    @NotEmpty(message="name should not be empty")
	private String dept_name;
	
	@ApiModelProperty(notes = "The Department Location")
	@NotEmpty(message="Designation should not be Empty")
	private String dept_loc;
	
	@ApiModelProperty(notes = "The database generated Employee ID")
	@NotNull(message="Please Provide ID")
	@Min(value=3,message="ID should not be smaller than three digit")
	@Max(value=8,message="ID should not be greater than eight digit")
	private int emp_id;

	public DeptDto(int dept_id, String dept_name, String dept_loc, int emp_id) {
		super();
		this.dept_id = dept_id;
		this.dept_name = dept_name;
		this.dept_loc = dept_loc;
		this.emp_id = emp_id;
	}

	public int getDept_id() {
		return dept_id;
	}

	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}

	public String getDept_name() {
		return dept_name;
	}

	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}

	public String getDept_loc() {
		return dept_loc;
	}

	public void setDept_loc(String dept_loc) {
		this.dept_loc = dept_loc;
	}

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	@Override
	public String toString() {
		return "DeptDto [dept_id=" + dept_id + ", dept_name=" + dept_name + ", dept_loc=" + dept_loc + ", emp_id="
				+ emp_id + "]";
	}

	

}
